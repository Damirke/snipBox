package main

import "snippetbox.mauk14/internal/models"

type templateData struct {
	Snippet *models.Snippet
}
